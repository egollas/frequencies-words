### Readme

## Setup application

Node version  17.6.0

```
 npm install
 npm run start
```


## Postman setup
Import postman collection test.postman_collection.json

