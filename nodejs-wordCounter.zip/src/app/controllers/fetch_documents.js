const processLineByLine = require("../services/wordCounter");

async function create(req, reply) {
    const files = await req.saveRequestFiles()
    let {filepath, fields: {topN: {value:topN = 0} = {}} = {}} = files[0]
    topN = Number(topN);
    const result  = await processLineByLine(topN, filepath)

    reply.send(result);
}

module.exports = async (fastify) => {
    fastify.route({
      method: "POST",
      url: "/",
      handler: create,
    });
  };

