const fetchDocumentController = require("./controllers/fetch_documents");

function fetchDocumentRoutes(fastify, _options, done) {
    fastify.register(fetchDocumentController, { prefix: "/v1" });
    done();
  }

module.exports = fetchDocumentRoutes;

