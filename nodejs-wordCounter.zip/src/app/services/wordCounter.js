const fs = require('fs');
const readline = require('readline');

const generateCountWords = (result, lines) => {
  // Remove all the characters from lines
  // lowercase all the characters and create an array with results
  // filter only for valid content
  const words = lines.replace(/\s+/g, " ")
  .replace(/[.,?!;()"'-]/g,"")
  .toLowerCase()
  .split(" ")
  .filter(Boolean);

  // init word count for list
  words.forEach(c => {
    result[c]||=0;
    result[c]++;
  });

  return result;
}

const formatResults = (result, topN) => {
  const values = Object.values(result)
  const keys = Object.keys(result)
  //remove repeted count values and sort them for highhest ones
  const r = [...new Set(values)].sort((a,b) => b - a ).slice(0, topN);

  const formattedInformation = r.reduce((total, value) => {
    const index = values.indexOf(value);
    const word = keys[index]

    return [
      ...total,
      {
        "word": word,
        "count": value,
      }
    ];
  }, []);
  return formattedInformation;
}


async function processLineByLine(topN, file) {
  try {
    console.time('codezup')
    let result = {};
    const rl = readline.createInterface({
      input: fs.createReadStream(file),
      crlfDelay: Infinity
    });

    let lineBlock = "";
    let lineMax = 0;

    for await (const line of rl) {
      if(lineMax++ === 10000){
        generateCountWords(result, lineBlock)
        lineMax = 0;
        lineBlock = "";
      }else{
        lineMax += 1;
        lineBlock += ` ${line}`;
      }
    }

    if(lineMax > 0){
      generateCountWords(result, lineBlock)
    }

    const formmattedResult = formatResults(result, topN);

    console.log('Reading file line by line with readline done.');
    const used = process.memoryUsage().heapUsed / 1024 / 1024;
    console.log(`The script uses approximately ${Math.round(used * 100) / 100} MB`);
    console.timeEnd('codezup')

    return formmattedResult;
  } catch (err) {
    console.error(err);
  }
};

module.exports =  processLineByLine;
